'use strict';

const list = RenderList();
const gltf = list.find({ layer: "Draw", target: "EffectRT" });
if (gltf)
    list.clear();
const insert = () => {
    if (!gltf)
        return;
    const last = list.last();
    if (!last)
        throw new Error("Unable to insert GLTF model: unable to find a render target since render list is empty");
    gltf.target = last.target;
    list.add(gltf);
};
function RenderList() {
    const list = bnb.scene.getRenderList();
    return {
        add(...tasks) {
            for (const { layer, target, subgeoms = [] } of tasks)
                if (subgeoms.length > 0)
                    list.addTask(layer, target, subgeoms);
                else
                    list.addTask(layer, target);
        },
        find(predicate) {
            for (let i = 0, len = list.getTasksCount(); i < len; ++i) {
                const layer = list.getTaskLayer(i);
                const target = list.getTaskTarget(i);
                if (layer.getName() !== predicate.layer)
                    continue;
                if (target.getName() !== predicate.target)
                    continue;
                const subgeoms = list.getTaskSubGeometries(i);
                return { layer, target, subgeoms };
            }
            return;
        },
        last() {
            const last = list.getTasksCount() - 1;
            if (last < 0)
                return;
            return {
                layer: list.getTaskLayer(last),
                target: list.getTaskTarget(last),
                subgeoms: list.getTaskSubGeometries(last),
            };
        },
        clear() {
            list.clear();
        },
    };
}

exports.insert = insert;
