'use strict';

const makeup = require('./makeup.js');

Object.assign(globalThis, makeup.m);
/* Feel free to add your custom code below */

Eyes.color("0.8 0.8 0.8 1.0"); 
